// import java.util.*;
public class sum {
 public static void main(String[] args) {
    //variables
//       Scanner sc =new Scanner(System.in);        
//  try {
//     System.out.println("Enter the value of first number : ");
//     int a =sc.nextInt();
//     System.out.println("Enter the value of second number: ");
//     int b=sc.nextInt();
//     int sum=a+b;
//     System.out.println(sum);
// } finally {
//     sc.close();
// }
//print pattern using println funtion
// System.out.println("x");
// System.out.println("xx");
// System.out.println("xxx");
// System.out.println("xxxx");
// System.out.println("xxxxx");
// System.out.println("xxxxxx");
int a=10,b=5;
int sum =(a * b ) /( a- b);
System.out.print(sum);
}

}
