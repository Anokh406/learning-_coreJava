package leetCode;

public class solution {
    public static void main(String[] args) {
        int array[] = { 2, 5, 1, 3, 4, 7 };
        System.out.println(array[0]);
        // for (int i = 0; i < 5; i++) {
        // System.out.println(array[i]);

        // }

    }
}
